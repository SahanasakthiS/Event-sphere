package com.example.Eventsphere.controller;

import com.example.Eventsphere.model.Admin;
import com.example.Eventsphere.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:4200") 
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public String loginAdmin(@RequestBody Admin admin) {
        return adminService.login(admin.getUserId(), admin.getPassword());
    }
}
