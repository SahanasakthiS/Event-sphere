package com.example.Eventsphere.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.Eventsphere.model.Event;
import com.example.Eventsphere.repository.EventRepository;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.Base64;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = "http://localhost:4200") 
public class EventController {

    @Autowired
    private EventRepository eventRepository;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadEvent(@RequestParam("title") String title,
                                              @RequestParam("image") MultipartFile file) {
        try {
            Event event = new Event();
            event.setTitle(title);
            event.setImage(file.getBytes());  // Store the image as a byte array
            event.setFileType(file.getContentType());  // Store the file's MIME type
            eventRepository.save(event);  // Save the event to the DB
            return ResponseEntity.ok("Event uploaded successfully");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload");
        }
    }


    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getEvents() {
        List<Event> events = eventRepository.findAll();
        List<Map<String, Object>> response = events.stream().map(event -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", event.getId());
            map.put("title", event.getTitle());
            map.put("image", Base64.getEncoder().encodeToString(event.getImage()));  // Encode the image to Base64
            map.put("fileType", event.getFileType());
            return map;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }

}

