package com.example.Eventsphere.controller;

import com.example.Eventsphere.model.EventRegistration;
import com.example.Eventsphere.service.EventRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/event") // base URL
public class EventRegistrationController {

    @Autowired
    private EventRegistrationService service;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody EventRegistration registration) {
        service.register(registration);
        return ResponseEntity.ok("Event registered successfully");
    }
}
