package com.example.Eventsphere.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Eventsphere.model.Event;

public interface EventRepository extends JpaRepository<Event, Long> {
}
