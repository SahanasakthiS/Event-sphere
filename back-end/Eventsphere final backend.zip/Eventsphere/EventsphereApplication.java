package com.example.Eventsphere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsphereApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsphereApplication.class, args);
	}

}
