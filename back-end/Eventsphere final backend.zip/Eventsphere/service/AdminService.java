package com.example.Eventsphere.service;

import com.example.Eventsphere.model.Admin;

public interface AdminService {
    String login(String userId, String password);
}
