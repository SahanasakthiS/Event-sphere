package com.example.Eventsphere.service;

import com.example.Eventsphere.model.EventRegistration;
import com.example.Eventsphere.repository.EventRegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EventRegistrationService {

    @Autowired
    private EventRegistrationRepository repository;

    @Autowired
    private JavaMailSender mailSender;

    private final String adminEmail = "sahana130613@gmail.com";

    public EventRegistration register(EventRegistration registration) {
        // Simulate payment success (can integrate payment gateway here)
    	
    	   // Simulate payment success
        registration.setPaymentStatus("Paid");

        EventRegistration saved = repository.save(registration);

        // Send email to user
        sendEmail(
            registration.getEmailId(),
            "Event Registration Confirmation",
            "Dear " + registration.getUsername() +
            ",\n\nYou have successfully registered for the event: " + registration.getEventName() +
            " with the amount ₹" + registration.getAmount() + ".\n\nThank you!"
        );

        // Send email to admin
        sendEmail(
            adminEmail,
            "New Event Registration",
            "Student " + registration.getUsername() +
            " registered for event: " + registration.getEventName() +
            " with amount ₹" + registration.getAmount() + "."
        );

        return saved;
    }

    private void sendEmail(String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("sahana130613@gmail.com"); // Must match spring.mail.username
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        mailSender.send(message); // This line can throw 500 error if mail config is wrong
    }

}
