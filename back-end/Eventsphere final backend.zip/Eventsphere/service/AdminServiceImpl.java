package com.example.Eventsphere.service;

import com.example.Eventsphere.model.Admin;
import com.example.Eventsphere.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public String login(String userId, String password) {
        Optional<Admin> adminOpt = adminRepository.findByUserIdAndPassword(userId, password);
        return adminOpt.isPresent() ? "Login successful!" : "Invalid credentials!";
    }
}
