package com.example.Eventsphere.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class MailTestRunner implements CommandLineRunner {

    @Autowired
    private JavaMailSender mailSender;

    @Override
    public void run(String... args) throws Exception {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("sahana130613@gmail.com");  // Your email configured in properties
            message.setTo("sahana130613@gmail.com");    // Your email to receive test mail
            message.setSubject("Test Mail from EventSphere");
            message.setText("Hello Skyla! This is a test mail from your Spring Boot app.");
            mailSender.send(message);
            System.out.println("Test mail sent successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

